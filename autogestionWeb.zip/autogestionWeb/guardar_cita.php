<?php

session_start();
include "conexion.php";

$idcliente = $_SESSION['idcliente'];

$marca = $_POST['marca'];
$modelo = $_POST['modelo'];
$anio = $_POST['anio'];
$color = $_POST['color'];
$placas = $_POST['placas'];

$problema = $_POST['problema'];
$fecha = $_POST['fecha'];
$hora = $_POST['hora'];


$verificar = "SELECT * FROM agenda WHERE fecha='$fecha' AND hora='$hora'";
$res = $conn->query($verificar);

if($res->num_rows > 0){

echo "Esta hora ya fue reservada";
exit;

}


$sql1 = "INSERT INTO autos(idcliente,marca,modelo,anio,color,placas)
VALUES('$idcliente','$marca','$modelo','$anio','$color','$placas')";

$conn->query($sql1);

$idauto = $conn->insert_id;


$sql2 = "INSERT INTO agenda(idcliente,idauto,fecha,hora)
VALUES('$idcliente','$idauto','$fecha','$hora')";

$conn->query($sql2);


$sql3 = "INSERT INTO trabajos(idauto,descripcionproblema,idcliente,origen)
VALUES('$idauto','$problema','$idcliente','WEB')";

$conn->query($sql3);


$mensaje="Cita confirmada Fecha:$fecha Hora:$hora Auto:$marca $modelo Placas:$placas Problema:$problema";

$telefono="5654439939";

header("Location:https://wa.me/52$telefono?text=".urlencode($mensaje));

?>