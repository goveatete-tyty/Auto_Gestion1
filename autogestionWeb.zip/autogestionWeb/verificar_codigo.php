<?php

session_start();
include "conexion.php";

if(!isset($_SESSION['registro']['correo'])){

echo "<script>
alert('Sesión expirada');
window.location='registro.html';
</script>";
exit();

}

$correo=$_SESSION['registro']['correo'];
$codigo=trim($_POST['codigo']);

$sql="SELECT codigo_verificacion,codigo_expira 
FROM clientes 
WHERE correo='$correo'";

$res=$conn->query($sql);

if($res->num_rows>0){

$row=$res->fetch_assoc();

$codigo_bd=trim($row['codigo_verificacion']);
$expira=$row['codigo_expira'];

if(strtotime($expira) < time()){

echo "<script>
alert('El código expiró, solicita uno nuevo');
window.location='verificar_codigo.html';
</script>";
exit();

}

if($codigo_bd === $codigo){

$conn->query("UPDATE clientes 
SET verificado=1,
codigo_verificacion=NULL,
codigo_expira=NULL
WHERE correo='$correo'");

echo "<script>
alert('Cuenta verificada correctamente');
window.location='login.html';
</script>";

}else{

echo "<script>
alert('Código incorrecto');
window.location='verificar_codigo.html';
</script>";

}

}else{

echo "<script>
alert('Usuario no encontrado');
window.location='registro.html';
</script>";

}

?>