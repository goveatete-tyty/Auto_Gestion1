<?php

session_start();

include "conexion.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$correo=$_POST['correo'];
$contrasena=$_POST['contrasena'];

$sql="SELECT * FROM clientes WHERE correo='$correo' AND contrasena='$contrasena'";

$result=$conn->query($sql);

if($result->num_rows>0){

$row=$result->fetch_assoc();

$_SESSION['idcliente']=$row['idcliente'];
$_SESSION['nombre']=$row['nombre'];

header("Location: perfiles.html");
exit();

}else{

echo "<script>
alert('Usuario o contraseña incorrectos');
window.location='login.html';
</script>";

}

}else{

echo "Acceso no permitido";

}

?>