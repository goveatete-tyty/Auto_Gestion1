<?php

session_start();
include "conexion.php";

$nombre=$_POST['nombre'];
$ap=$_POST['apellidopaterno'];
$am=$_POST['apellidomaterno'];
$tel=$_POST['telefono'];
$correo=$_POST['correo'];
$con=$_POST['contrasena'];
$dir=$_POST['direccion'];

$codigo=rand(100000,999999);

$fecha=date("Y-m-d");
$hora=date("H:i:s");

$expira=date("Y-m-d H:i:s",strtotime("+5 minutes"));

$sql="INSERT INTO clientes
(nombre,apellidopaterno,apellidomaterno,telefono,correo,contrasena,direccion,fecha_registro,hora_registro,codigo_verificacion,codigo_expira,verificado)
VALUES
('$nombre','$ap','$am','$tel','$correo','$con','$dir','$fecha','$hora','$codigo','$expira',0)";

if($conn->query($sql)){

$_SESSION['registro']=[
"correo"=>$correo
];

include "enviar_codigo.php";

enviarCodigo($correo,$codigo);

header("Location: verificar_codigo.html");
exit();

}else{

echo "Error: ".$conn->error;

}

?>