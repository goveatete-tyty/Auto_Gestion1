<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

function enviarCodigo($correo,$codigo){

$mail = new PHPMailer(true);

try{

$mail->isSMTP();
$mail->Host='smtp.gmail.com';
$mail->SMTPAuth=true;
$mail->Username='santillangel83@gmail.com';
$mail->Password='yygi ggsx arjw nlid';
$mail->SMTPSecure='tls';
$mail->Port=587;

$mail->setFrom('santillangel83@gmail.com','AutoGestion');

$mail->addAddress($correo);

$mail->Subject="Codigo de verificacion";

$mail->Body="Tu codigo de verificacion es: $codigo";

$mail->send();

}catch(Exception $e){

echo "Error: ".$mail->ErrorInfo;

}

}
?>