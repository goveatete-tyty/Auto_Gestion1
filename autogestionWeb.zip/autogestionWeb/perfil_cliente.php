<?php

session_start();
include "conexion.php";

if(!isset($_SESSION['idcliente'])){
header("Location: login.html");
exit();
}

$idcliente=$_SESSION['idcliente'];

$sql="SELECT * FROM clientes WHERE idcliente='$idcliente'";
$res=$conn->query($sql);
$cliente=$res->fetch_assoc();

$sqlAutos="SELECT * FROM autos WHERE idcliente='$idcliente'";
$resAutos=$conn->query($sqlAutos);

?>
<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">
<title>Perfil Cliente</title>

<link rel="stylesheet" href="perfil_cliente.css">

</head>

<body>

<?php include("perfil_cliente.html"); ?>

</body>

</html>