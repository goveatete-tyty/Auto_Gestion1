<?php

include "conexion.php";

$fecha = $_GET['fecha'];

$sql = "SELECT hora FROM agenda WHERE fecha='$fecha'";

$result = $conn->query($sql);

$horas = [];

while($row = $result->fetch_assoc()){
    $horas[] = $row['hora'];
}

echo json_encode($horas);

?>