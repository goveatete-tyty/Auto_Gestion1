<?php

include "conexion.php";

$idcliente=1;

$marca=$_POST['marca'];
$modelo=$_POST['modelo'];
$anio=$_POST['anio'];
$color=$_POST['color'];
$placas=$_POST['placas'];

$sql="INSERT INTO autos(idcliente,marca,modelo,anio,color,placas)
VALUES('$idcliente','$marca','$modelo','$anio','$color','$placas')";

$conn->query($sql);

echo $conn->insert_id;

?>