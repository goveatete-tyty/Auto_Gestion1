<?php

include "conexion.php";

$fecha=$_GET['fecha'];

$sql="SELECT COUNT(*) as total FROM agenda WHERE fecha='$fecha'";

$result=$conn->query($sql);

$row=$result->fetch_assoc();

echo $row['total'];

?>