function irRegistro(){

window.location="registro.html"

}

function irLogin(){

window.location="login.html"

}