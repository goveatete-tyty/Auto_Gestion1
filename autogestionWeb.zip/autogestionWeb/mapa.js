const mapa=L.map('mapa').setView([19.709, -98.968],13)

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
maxZoom:19
}).addTo(mapa)

const universidad=[19.7095,-98.9681]
const taller=[19.7035,-98.9580]

L.marker(universidad)
.addTo(mapa)
.bindPopup("Universidad Tecnológica de Tecámac")

L.marker(taller)
.addTo(mapa)
.bindPopup("Taller Don Beto")

const ruta=L.polyline([universidad,taller],{
color:'yellow',
weight:5
}).addTo(mapa)

mapa.fitBounds(ruta.getBounds())