function abrir(id){

if(id==6){

window.location="perfil_taller.html?id="+id

}else{

alert("Este taller solo permite consultas por el momento")

}

}