const calendario=document.getElementById("calendario")

const meses=[
"Enero","Febrero","Marzo","Abril",
"Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre"
]

const hoy=new Date()

for(let m=0;m<12;m++){

let mesDiv=document.createElement("div")
mesDiv.className="mes"

let titulo=document.createElement("h3")
titulo.innerText=meses[m]+" 2026"

mesDiv.appendChild(titulo)

let diasDiv=document.createElement("div")
diasDiv.className="dias"

let primerDia=new Date(2026,m,1).getDay()
let diasMes=new Date(2026,m+1,0).getDate()

for(let i=0;i<primerDia;i++){

let vacio=document.createElement("div")
diasDiv.appendChild(vacio)

}

for(let d=1;d<=diasMes;d++){

let fecha=new Date(2026,m,d)

let div=document.createElement("div")
div.className="dia"
div.innerText=d

let fechaStr=fecha.toISOString().split('T')[0]

if(fecha<hoy){

div.classList.add("rojo")

}

else if(fecha.getDay()==0 || fecha.getDay()==6){

div.classList.add("finsemana")

div.onclick=()=>alert("Día inhábil")

}

else{

fetch("horarios.php?fecha="+fechaStr)

.then(r=>r.text())

.then(total=>{

if(total>=3){

div.classList.add("rojo")

div.title="Día lleno"

}

else{

div.classList.add("disponible")

div.onclick=()=>{

window.location="agenda.html?fecha="+fechaStr

}

}

})

}

diasDiv.appendChild(div)

}

mesDiv.appendChild(diasDiv)

calendario.appendChild(mesDiv)

}