<?php

session_start();
include "conexion.php";
include "enviar_codigo.php";

if(!isset($_SESSION['registro']['correo'])){
header("Location: registro.html");
exit();
}

$correo=$_SESSION['registro']['correo'];

$codigo=rand(100000,999999);

$expira=date("Y-m-d H:i:s",strtotime("+5 minutes"));

$conn->query("UPDATE clientes 
SET codigo_verificacion='$codigo',
codigo_expira='$expira'
WHERE correo='$correo'");

enviarCodigo($correo,$codigo);

header("Location: verificar_codigo.html");

?>