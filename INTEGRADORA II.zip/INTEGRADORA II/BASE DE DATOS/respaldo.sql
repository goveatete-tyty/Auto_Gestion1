CREATE DATABASE IF NOT EXISTS autogestion;
USE autogestion;

-- ===============================
-- TABLA usuarios
-- ===============================
CREATE TABLE usuarios (
    idusuario INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    apellidopaterno VARCHAR(100) NOT NULL,
    apellidomaterno VARCHAR(100),
    edad INT,
    telefono VARCHAR(20),
    correo VARCHAR(100) NOT NULL UNIQUE,
    area ENUM('ADMINISTRADOR','TRABAJADOR') NOT NULL,
    contrasena VARCHAR(255) NOT NULL,
    activo BOOLEAN DEFAULT TRUE
);

-- ===============================
CREATE TABLE clientes (
    idcliente INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellidopaterno VARCHAR(100) NOT NULL,
    apellidomaterno VARCHAR(100),
    telefono VARCHAR(20),
    correo VARCHAR(100) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    direccion VARCHAR(200)
);

-- ===============================
CREATE TABLE especialidades (
    idespecialidad INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE
);

-- ===============================
CREATE TABLE trabajadores (
    idtrabajador INT AUTO_INCREMENT PRIMARY KEY,
    idusuario INT NOT NULL,
    idespecialidad INT NOT NULL,
    FOREIGN KEY (idusuario) REFERENCES usuarios(idusuario),
    FOREIGN KEY (idespecialidad) REFERENCES especialidades(idespecialidad)
);

-- ===============================
CREATE TABLE autos (
    idauto INT AUTO_INCREMENT PRIMARY KEY,
    idcliente INT NOT NULL,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    anio INT,
    color VARCHAR(30),
    placas VARCHAR(20) NOT NULL UNIQUE,
    FOREIGN KEY (idcliente) REFERENCES clientes(idcliente)
);

-- ===============================
CREATE TABLE trabajos (
    idtrabajo INT AUTO_INCREMENT PRIMARY KEY,
    idauto INT NOT NULL,
    idtrabajador INT,
    descripcionproblema TEXT NOT NULL,
    fecharecepcion DATE NOT NULL,
    fechareparacion DATE,
    estado ENUM('PENDIENTE','EN_PROCESO','REPARADO') DEFAULT 'PENDIENTE',
    origen ENUM('WEB','TALLER') DEFAULT 'WEB',
    FOREIGN KEY (idauto) REFERENCES autos(idauto),
    FOREIGN KEY (idtrabajador) REFERENCES trabajadores(idtrabajador)
);

-- ===============================
CREATE TABLE agenda (
    idagenda INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    idtrabajo INT NOT NULL,
    FOREIGN KEY (idtrabajo) REFERENCES trabajos(idtrabajo)
);

-- ===============================
CREATE TABLE historial_reparaciones (
    idhistorial INT AUTO_INCREMENT PRIMARY KEY,
    idtrabajo INT NOT NULL,
    quesereparo TEXT NOT NULL,
    fechainicio DATE,
    fechafin DATE,
    FOREIGN KEY (idtrabajo) REFERENCES trabajos(idtrabajo)
);

-- ===============================
CREATE TABLE pagos (
    idpago INT AUTO_INCREMENT PRIMARY KEY,
    idtrabajo INT NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    dinerorecibido DECIMAL(10,2) NOT NULL,
    cambio DECIMAL(10,2) NOT NULL,
    fechapago DATE NOT NULL,
    FOREIGN KEY (idtrabajo) REFERENCES trabajos(idtrabajo)
);

-- ===============================
-- INSERT usuarios (tus datos)
-- ===============================

INSERT INTO usuarios 
(idusuario, codigo, nombre, apellidopaterno, apellidomaterno, edad, telefono, correo, area, contrasena, activo)
VALUES
(2,'2','W','W','W',18,'1234567890','QWE','ADMINISTRADOR','123',1),
(3,'3r3r','rrr','rrrr','rrr',18,'4532123456','qwe','ADMINISTRADOR','123',1),
(4,'hqidhq3278','eee','ee','ee',20,'8596782536','asd','TRABAJADOR','asd',1),
(5,'123','qwe','qwe','qwe',22,'7418529632','zxc','ADMINISTRADOR','zxc',1),
(8,'jdi383','TETA','TETON','TEETON',25,'6576890987','PUTA@GMAIL.COM','TRABAJADOR','123',1);
