package Metodos; 
// Define el paquete donde se encuentra esta clase
//@author santi
import java.sql.Connection;
// Importa la clase Connection que permite manejar la conexión con la base de datos
import java.sql.DriverManager;
// Importa DriverManager que se encarga de crear la conexión con la base de datos
// Clase Conexion: se encarga de conectar el sistema con la base de datos PostgreSQL
public class Conexion {
    
    // Variable que almacenará la conexión activa con la base de datos
    private Connection con;

    
    // Constructor de la clase Conexion
    // Se ejecuta automáticamente cuando se crea un objeto Conexion
    public Conexion() {
        
        
        try{
            String myBD = "jdbc:mysql://localhost:3306/autogestion?serverTimezone=UTC";
            con = DriverManager.getConnection(myBD, "root", "");
                
            
        }catch(Exception e){
            
            // Mensaje de error si la conexión falla
            System.out.println("ERROR: "+e.getMessage());
            
            // Muestra el error completo
            System.out.println("ERROR: "+e.toString());
        }
    }
    public Connection getCon() {
        return con;
    }
    
}











