package Metodos;
// @author santi
public class Login {
    private int idusuario;
    private String codigo;
    private String nombre;
    private String apellidopaterno;
    private String apellidomaterno;
    private int edad;
    private String telefono;
    private String correo;
    private AreaUsuario area;
    private String contrasena;

    public enum AreaUsuario {
    
    ADMINISTRADOR,
        TRABAJADOR
}

    
    public Login() {
    } 
    // Constructor con parámetros
    // Se usa para crear un objeto Login con todos sus datos
    

    public Login(int idusuario, String codigo, String nombre, String apellidopaterno, String apellidomaterno, int edad, String telefono, String correo, AreaUsuario area, String contrasena) {
        this.idusuario = idusuario;
        this.codigo = codigo;
        this.nombre = nombre;
        this.apellidopaterno = apellidopaterno;
        this.apellidomaterno = apellidomaterno;
        this.edad = edad;
        this.telefono = telefono;
        this.correo = correo;
        this.area = area;
        this.contrasena = contrasena;
    }
    
    // =========================
    // MÉTODOS GET Y SET
    // =========================


    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidopaterno() {
        return apellidopaterno;
    }

    public void setApellidopaterno(String apellidopaterno) {
        this.apellidopaterno = apellidopaterno;
    }

    public String getApellidomaterno() {
        return apellidomaterno;
    }

    public void setApellidomaterno(String apellidomaterno) {
        this.apellidomaterno = apellidomaterno;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
    this.edad = edad;
}


    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
public void setArea(AreaUsuario area) {
    this.area = area;
}

public AreaUsuario getArea() {
    return this.area;
}

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

}
