package Metodos;
// @author santi

// Importación de clases necesarias para conexión y manejo de datos
import Metodos.Login.AreaUsuario;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;

// Clase LoginDAO: se encarga de realizar todas las operaciones con la tabla usuarios en la base de datos
public class LoginDAO {

    // Variables para conexión y consultas
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    // Objeto de conexión a la base de datos
    Conexion cn = new Conexion();
    
    
    // Método para iniciar sesión
    // Verifica si el correo y contraseña existen en la base de datos
    public Login Log(String Correo, String Contrasena){

        Login l = new Login();
        String sql = "SELECT * FROM usuarios WHERE correo = ? AND contrasena = ?";

        try{
            con = cn.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, Correo);
            ps.setString(2, Contrasena);
            rs = ps.executeQuery();

            // Si encuentra el usuario, guarda sus datos
            if(rs.next()){
                l.setIdusuario(rs.getInt("idusuario"));
                l.setCodigo(rs.getString("codigo"));
                l.setNombre(rs.getString("nombre"));
                l.setCorreo(rs.getString("correo"));
                l.setEdad(rs.getInt("edad"));
                l.setContrasena(rs.getString("contrasena"));
                l.setArea(AreaUsuario.valueOf(rs.getString("area"))); 
            }

        }catch (SQLException AutoGestion) {
            System.out.println(AutoGestion.toString());
        }

        return l;
    }

    
    // Método para registrar un nuevo usuario en la base de datos
    public boolean RegistrarUsuarios(Login log){

        String sql = "INSERT INTO usuarios (codigo, nombre, apellidopaterno, apellidomaterno, edad, telefono, correo, area, contrasena) VALUES (?, ?, ?, ?, ?, ?, ?, ?::area_usuario, ?)";

        try{
            con = cn.getCon();
            ps = con.prepareStatement(sql);

            // Se insertan los datos del objeto Login
            ps.setString(1, log.getCodigo());
            ps.setString(2, log.getNombre());
            ps.setString(3, log.getApellidopaterno());
            ps.setString(4, log.getApellidomaterno());
            ps.setInt(5, log.getEdad());
            ps.setString(6, log.getTelefono());
            ps.setString(7, log.getCorreo());
            ps.setString(8, log.getArea().name()); 
            ps.setString(9, log.getContrasena());

            ps.execute();
            return true;

        }catch(SQLException AutoGestion){
            System.out.println(AutoGestion.toString());
            return false;
        }
    }

    
    // Método para consultar las edades y agregarlas a un ComboBox
    public void ConsultarEdad(JComboBox usuarios){

        String sql = "SELECT edad FROM usuarios";

        try{
            con = cn.getCon();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while(rs.next()){
                usuarios.addItem(rs.getInt("edad")); 
            }

        }catch (SQLException AutoGestion) {
            System.out.println(AutoGestion.toString());
        }
    }

    
    // Método para consultar las áreas (ADMINISTRADOR o TRABAJADOR) y agregarlas a un ComboBox
    public void ConsultarArea(JComboBox usuarios){

        String sql = "SELECT area FROM usuarios";

        try{
            con = cn.getCon();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while(rs.next()){
                usuarios.addItem(AreaUsuario.valueOf(rs.getString("area"))); 
            }

        }catch (SQLException AutoGestion) {
            System.out.println(AutoGestion.toString());
        }
    }

    
    // Método para eliminar un usuario usando su código
    public boolean EliminarUsuarios(String Codigo){

        String sql = "DELETE FROM usuarios WHERE codigo = ?";

        try{
            con = cn.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, Codigo);
            ps.execute();
            return true;

        } catch (SQLException AutoGestion) {
            System.out.println(AutoGestion.toString());
            return false;

        } finally{
            try{
                con.close();
            }catch (SQLException AutoGestion) {
                System.out.println(AutoGestion.toString());
            }
        }
    }


    // Método para buscar un usuario por su código
    public Login BuscarUsuarios(String Codigo){

        Login log = new Login();
        String sql = "SELECT * FROM usuarios WHERE codigo = ?";

        try{
            con = cn.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, Codigo);
            rs = ps.executeQuery();

            // Si encuentra el usuario, guarda sus datos
            if(rs.next()){
                log.setNombre(rs.getString("nombre"));
                log.setApellidopaterno(rs.getString("apellidopaterno"));
                log.setApellidomaterno(rs.getString("apellidomaterno"));
                log.setEdad(rs.getInt("edad"));
                log.setTelefono(rs.getString("telefono"));
                log.setCorreo(rs.getString("correo"));
                log.setArea(AreaUsuario.valueOf(rs.getString("area"))); 
                log.setContrasena(rs.getString("contrasena"));
            }

        }catch(SQLException AutoGestion){
            System.out.println(AutoGestion.toString());
        }

        return log;
    }

    
    // Método para obtener los datos del perfil del usuario
    public Login Perf(String Correo, String Contrasena){

        Login l = new Login();
        String sql = "SELECT * FROM usuarios WHERE correo = ? AND contrasena = ?";

        try{
            con = cn.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, Correo);
            ps.setString(2, Contrasena);
            rs = ps.executeQuery();

            if(rs.next()){
                l.setIdusuario(rs.getInt("idusuario"));
                l.setCodigo(rs.getString("codigo"));
                l.setNombre(rs.getString("nombre"));
                l.setCorreo(rs.getString("correo"));
                l.setEdad(rs.getInt("edad"));
                l.setContrasena(rs.getString("contrasena"));
                l.setArea(AreaUsuario.valueOf(rs.getString("area")));
            }

        }catch (SQLException AutoGestion) {
            System.out.println(AutoGestion.toString());
        }

        return l;
    }

    
    // Método para modificar los datos de un usuario existente
    public boolean ModificarUsuarios(Login log){

        String sql = "UPDATE usuarios SET codigo = ?, nombre = ?, apellidopaterno = ?, apellidomaterno = ?, edad = ?, telefono = ?, correo = ?, area = ?::area_usuario, contrasena = ? WHERE codigo = ?";

        try{
            con = cn.getCon();
            ps = con.prepareStatement(sql);

            // Se actualizan los datos del usuario
            ps.setString(1, log.getCodigo());
            ps.setString(2, log.getNombre());
            ps.setString(3, log.getApellidopaterno());
            ps.setString(4, log.getApellidomaterno());
            ps.setInt(5, log.getEdad());
            ps.setString(6, log.getTelefono());
            ps.setString(7, log.getCorreo());
            ps.setString(8, log.getArea().name());
            ps.setString(9, log.getContrasena());
            ps.setString(10, log.getCodigo());

            ps.execute();
            return true;

        } catch (SQLException AutoGestion){
            System.out.println(AutoGestion.toString());
            return false;

        } finally{
            try{
                con.close();
            }catch(SQLException AutoGestion){
                System.out.println(AutoGestion.toString());
            }
        }
    }
}
