1️⃣ CREAR BASE DE DATOS
CREATE DATABASE autogestion;


Conectarse:

\c autogestion;

2️⃣ TIPOS ENUM (POSTGRESQL)
🔐 Rol del usuario (app de escritorio)
CREATE TYPE area_usuario AS ENUM ('ADMINISTRADOR', 'TRABAJADOR');

📌 Estado del trabajo
CREATE TYPE estado_trabajo AS ENUM ('PENDIENTE', 'EN_PROCESO', 'REPARADO');

🌐 Origen del trabajo
CREATE TYPE origen_trabajo AS ENUM ('WEB', 'TALLER');

3️⃣ USUARIOS (SOLO APP DE ESCRITORIO)
CREATE TABLE usuarios (
    id_usuario SERIAL PRIMARY KEY,
    codigo VARCHAR(20) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    apellido_paterno VARCHAR(100) NOT NULL,
    apellido_materno VARCHAR(100),
    edad INT,
    telefono_celular VARCHAR(20),
    correo VARCHAR(100) UNIQUE NOT NULL,
    area area_usuario NOT NULL,
    contrasena VARCHAR(255) NOT NULL,
    activo BOOLEAN DEFAULT TRUE
);


📌 Aquí inician sesión:

Administrador

Trabajadores

4️⃣ ESPECIALIDADES
CREATE TABLE especialidades (
    id_especialidad SERIAL PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL
);

5️⃣ TRABAJADORES
CREATE TABLE trabajadores (
    id_trabajador SERIAL PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_especialidad INT NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
    FOREIGN KEY (id_especialidad) REFERENCES especialidades(id_especialidad)
);


📌 Regla lógica:

El usuario debe tener área = TRABAJADOR

6️⃣ CLIENTES (WEB + ESCRITORIO)
CREATE TABLE clientes (
    id_cliente SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido_paterno VARCHAR(100) NOT NULL,
    apellido_materno VARCHAR(100),
    telefono VARCHAR(20),
    correo VARCHAR(100) UNIQUE NOT NULL,
    contrasena VARCHAR(255) NOT NULL,
    direccion VARCHAR(200)
);


📌 Aquí:

Se registran desde la web

La app de escritorio solo los consulta

7️⃣ AUTOS
CREATE TABLE autos (
    id_auto SERIAL PRIMARY KEY,
    id_cliente INT NOT NULL,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    anio INT,
    color VARCHAR(30),
    placas VARCHAR(20) UNIQUE NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
);

8️⃣ TRABAJOS (PUENTE ENTRE WEB Y ESCRITORIO 🔥)
CREATE TABLE trabajos (
    id_trabajo SERIAL PRIMARY KEY,
    id_auto INT NOT NULL,
    id_trabajador INT,
    descripcion_problema TEXT NOT NULL,
    fecha_recepcion DATE NOT NULL,
    fecha_reparacion DATE,
    estado estado_trabajo DEFAULT 'PENDIENTE',
    origen origen_trabajo DEFAULT 'WEB',
    FOREIGN KEY (id_auto) REFERENCES autos(id_auto),
    FOREIGN KEY (id_trabajador) REFERENCES trabajadores(id_trabajador)
);


📌 Cuando viene de la web:

estado = PENDIENTE

id_trabajador = NULL

origen = WEB

📌 El administrador asigna el trabajador desde escritorio.

9️⃣ AGENDA (SOLO SE CREA DESDE LA WEB)
CREATE TABLE agenda (
    id_agenda SERIAL PRIMARY KEY,
    fecha DATE NOT NULL,
    id_trabajo INT NOT NULL,
    FOREIGN KEY (id_trabajo) REFERENCES trabajos(id_trabajo)
);


📌 Reglas:

El calendario solo está en la web

Máximo 6 autos por día

La app de escritorio solo visualiza

🔟 HISTORIAL DE REPARACIONES
CREATE TABLE historial_reparaciones (
    id_historial SERIAL PRIMARY KEY,
    id_trabajo INT NOT NULL,
    que_se_reparo TEXT NOT NULL,
    fecha_inicio DATE,
    fecha_fin DATE,
    FOREIGN KEY (id_trabajo) REFERENCES trabajos(id_trabajo)
);


📌 Lo llenan los trabajadores.

1️⃣1️⃣ PAGOS
CREATE TABLE pagos (
    id_pago SERIAL PRIMARY KEY,
    id_trabajo INT NOT NULL,
    precio NUMERIC(10,2) NOT NULL,
    dinero_recibido NUMERIC(10,2) NOT NULL,
    cambio NUMERIC(10,2) NOT NULL,
    fecha_pago DATE NOT NULL,
    FOREIGN KEY (id_trabajo) REFERENCES trabajos(id_trabajo)
);


📌 El cambio se calcula, no se captura.